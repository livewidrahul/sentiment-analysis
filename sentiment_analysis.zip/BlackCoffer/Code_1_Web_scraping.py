import openpyxl
import requests
from bs4 import BeautifulSoup
import os

# Function to extract article text from a given URL
def extract_article_text(url):
    try:
        # Send a GET request to the URL
        response = requests.get(url)
        # Parse the HTML content of the page
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Find the article title
        article_title = soup.find('h1').get_text().strip()
        
        # Find all paragraphs containing the article text
        article_paragraphs = soup.find_all(['p', 'ol'])
        
        # Remove unwanted paragraphs
        cleaned_paragraphs = []
        for p in article_paragraphs:
            # Exclude paragraphs with specific classes or styles
            if 'tdm-descr' not in p.get('class', []) and 'td_block_wrap' not in p.get('class', []):
                cleaned_paragraphs.append(p)
        
        # Extract text from cleaned paragraphs
        article_text = ' '.join([p.get_text().strip() for p in cleaned_paragraphs])
        
        return article_title, article_text
    except Exception as e:
        print(f"Error occurred while extracting text from {url}: {str(e)}")
        return None, None

# Load the Excel file
wb = openpyxl.load_workbook('input.xlsx')
sheet = wb.active

# Define the output folder path
output_folder = 'input_folder'

# Create the output folder if it doesn't exist
os.makedirs(output_folder, exist_ok=True)

# Iterate through each row in the Excel sheet
for row in sheet.iter_rows(min_row=2, values_only=True):  # Start from the second row (skipping header)
    url_id, url = row
    print(f"Processing {url_id}...")

    # Extract article text from the URL
    article_title, article_text = extract_article_text(url)

    if article_title and article_text:
        # Save the extracted article text to a text file in the output folder
        with open(os.path.join(output_folder, f"{url_id}.txt"), "w", encoding="utf-8") as file:
            file.write(article_title + "\n\n")
            file.write(article_text)
            print(f"Article text extracted and saved to {url_id}.txt")
    else:
        print("Failed to extract article text.")

print("Extraction process completed.")
