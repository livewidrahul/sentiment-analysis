import os
import pandas as pd
import string
import nltk
import re
from collections import defaultdict
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords

# Function to load positive and negative word dictionaries
def load_word_dict(file_path):
    word_dict = set()
    with open(file_path, 'r', encoding='utf-8') as file:
        for word in file:
            word_dict.add(word.strip().lower())
    return word_dict

# Function to preprocess text
def preprocess_text(text):
    stop_words = set(stopwords.words('english'))
    punctuation = string.punctuation + '”“’'
    words = word_tokenize(text)
    words = [word.lower() for word in words if word.isalpha() and word.lower() not in stop_words and word not in punctuation]
    return words

# Function to count positive and negative scores
def count_scores(words, positive_words, negative_words):
    positive_score = sum(1 for word in words if word in positive_words)
    negative_score = sum(1 for word in words if word in negative_words)
    return positive_score, negative_score

# Function to calculate polarity score
def calculate_polarity_score(positive_score, negative_score):
    denominator = positive_score + negative_score + 0.000001
    polarity_score = (positive_score - negative_score) / denominator
    return polarity_score

# Function to calculate subjectivity score
def calculate_subjectivity_score(positive_score, negative_score, total_words):
    denominator = total_words + 0.000001
    subjectivity_score = (positive_score + negative_score) / denominator
    return subjectivity_score

# Function to calculate readability scores
def calculate_readability_scores(text):
    sentences = sent_tokenize(text)
    total_words = len(preprocess_text(text))
    total_sentences = len(sentences)
    
    # Average sentence length
    average_sentence_length = total_words / total_sentences
    
    # Percentage of complex words
    complex_words = [word for word in preprocess_text(text) if len(word) > 2]
    percentage_complex_words = len(complex_words) / total_words
    
    # Fog Index
    fog_index = 0.4 * (average_sentence_length + percentage_complex_words)
    
    return average_sentence_length, percentage_complex_words, fog_index

# Function to count syllables in a word
def count_syllables(word):
    exceptions = ["es", "ed"]
    syllable_count = 0
    word = word.lower()
    if word.endswith(tuple(exceptions)):
        return 1  # Exception: words ending with "es" or "ed" are counted as 1 syllable
    vowels = "aeiou"
    if word[0] in vowels:
        syllable_count += 1
    for index in range(1, len(word)):
        if word[index] in vowels and word[index - 1] not in vowels:
            syllable_count += 1
    if word.endswith('e'):
        syllable_count -= 1  # Exclude silent 'e' at the end of a word
    if syllable_count == 0:
        syllable_count = 1  # At least one syllable for any word
    return syllable_count

# Function to count complex words in a text
def count_complex_words(text):
    words = preprocess_text(text)
    complex_words = [word for word in words if count_syllables(word) > 2]
    return len(complex_words)

# Function to count the total number of cleaned words in a text
def count_word_count(text):
    words = preprocess_text(text)
    return len(words)

# Function to count personal pronouns in a text
def count_personal_pronouns(text):
    personal_pronouns = ['i', 'we', 'my', 'ours', 'us']
    # Exclude 'US' which might be mistaken for a personal pronoun
    text = re.sub(r'\bUS\b', '', text, flags=re.IGNORECASE)
    # Find counts of personal pronouns
    pronoun_count = sum(1 for word in text.split() if word.lower() in personal_pronouns)
    return pronoun_count

# Function to calculate average word length
def calculate_average_word_length(text):
    words = preprocess_text(text)
    total_characters = sum(len(word) for word in words)
    total_words = len(words)
    average_word_length = total_characters / total_words
    return average_word_length

# Path to folder containing input text files
input_folder = 'output_folder'
# Path to positive word dictionary
positive_words_path = 'positive-words.txt'
# Path to negative word dictionary
negative_words_path = 'negative-words.txt'

# Load positive and negative word dictionaries
positive_words = load_word_dict(positive_words_path)
negative_words = load_word_dict(negative_words_path)

# Dictionary to store scores for each text file
scores_dict = defaultdict(dict)

# Iterate over each text file in the input folder
for filename in os.listdir(input_folder):
    if filename.endswith('.txt'):
        with open(os.path.join(input_folder, filename), 'r', encoding='utf-8') as file:
            text = file.read()
        
        # Calculate readability scores
        avg_sentence_length, percentage_complex_words, fog_index = calculate_readability_scores(text)
        
        # Count positive and negative scores
        words = preprocess_text(text)
        positive_score, negative_score = count_scores(words, positive_words, negative_words)
        
        # Calculate polarity score
        polarity_score = calculate_polarity_score(positive_score, negative_score)
        
        # Calculate total words after cleaning
        total_words = len(words)
        
        # Calculate subjectivity score
        subjectivity_score = calculate_subjectivity_score(positive_score, negative_score, total_words)
        
        # Calculate complex word count
        complex_word_count = count_complex_words(text)
        
        # Calculate word count
        word_count = count_word_count(text)
        
        # Calculate syllable count per word
        syllable_count_per_word = sum(count_syllables(word) for word in words) / total_words
        
        # Count personal pronouns
        personal_pronoun_count = count_personal_pronouns(text)
        
        # Calculate average word length
        avg_word_length = calculate_average_word_length(text)
        
        # Remove ".txt" extension from filename
        filename_without_extension = os.path.splitext(filename)[0]
        
        # Store scores in the dictionary
        scores_dict[filename_without_extension] = {
            'Positive Score': positive_score,
            'Negative Score': negative_score,
            'Polarity Score': polarity_score,
            'Subjectivity Score': subjectivity_score,
            'Average Sentence Length': avg_sentence_length,
            'Percentage of Complex Words': percentage_complex_words,
            'Fog Index': fog_index,
            'Average Number of Words Per Sentence': avg_sentence_length,
            'Complex Word Count': complex_word_count,
            'Word Count': word_count,
            'Syllable Count Per Word': syllable_count_per_word,
            'Personal Pronoun Count': personal_pronoun_count,
            'Average Word Length': avg_word_length
        }

# Convert the dictionary to a DataFrame with "URL_ID" as index
df = pd.DataFrame.from_dict(scores_dict, orient='index')
df.index.name = 'URL_ID'  # Set the index name

# Save the DataFrame to an Excel file
output_excel_path = 'input2.xlsx'
df.to_excel(output_excel_path)
#print(f"Output data saved to {output_excel_path}")
