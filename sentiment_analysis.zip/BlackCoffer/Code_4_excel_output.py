import pandas as pd
from openpyxl import load_workbook

# Read Excel file into a pandas DataFrame
df1 = pd.read_excel('input.xlsx')
df2 = pd.read_excel('input2.xlsx')



# Merge the two DataFrames based on the common column
result = pd.merge(df1, df2, on='URL_ID')

# Display the resulting DataFrame
output_excel_path = 'input3.xlsx'
result.to_excel(output_excel_path)

# Load the Excel file
workbook = load_workbook('input3.xlsx')

# Select the active worksheet
worksheet = workbook.active

# Delete the first column
worksheet.delete_cols(1)

# Save the modified workbook
workbook.save('Output Data Structure.xlsx')

print("Output saved as 'Output Data Structure.xlsx'")

