import os
from nltk.tokenize import word_tokenize

# Function to load stop words from multiple .txt files
def load_stop_words(folder_path):
    stop_words = set()
    for filename in os.listdir(folder_path):
        if filename.endswith('.txt'):
            with open(os.path.join(folder_path, filename), 'r') as file:
                words = file.read().splitlines()
                stop_words.update(words)
    return stop_words

# Function to remove stop words from text
def remove_stop_words(text, stop_words):
    words = word_tokenize(text)
    filtered_words = [word for word in words if word.lower() not in stop_words]
    return ' '.join(filtered_words)

# Define folder path containing stop words files
folder_path = 'StopWords'

# Load stop words from folder
stop_words = load_stop_words(folder_path)

# Define input and output folder paths
input_folder = 'input_folder'
output_folder = 'output_folder'

# Iterate over each text file in the input folder
for filename in os.listdir(input_folder):
    if filename.endswith('.txt'):
        with open(os.path.join(input_folder, filename), 'r', encoding='utf-8') as file:
            text = file.read()
        
        # Remove stop words from text
        filtered_text = remove_stop_words(text, stop_words)
        
        # Save filtered text to output folder with the same filename
        output_file_path = os.path.join(output_folder, filename)
        with open(output_file_path, 'w', encoding='utf-8') as file:
            file.write(filtered_text)

        print(f"Stop words removed from {filename} and saved to {output_file_path}")
